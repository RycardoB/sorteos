import { db } from "./db";
import { tickets, raffles } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database...");

  // Check if raffle already exists
  const existingRaffles = await db.select().from(raffles);
  
  if (existingRaffles.length === 0) {
    // Create default raffle
    const [raffle] = await db.insert(raffles).values({
      title: "Toyota Tacoma 2024",
      description: "Sorteo de Toyota Tacoma 2024 completamente nueva",
      vehicleModel: "Toyota Tacoma",
      vehicleYear: 2024,
      vehicleImage: "/assets/image_1750636093510.png",
      ticketPrice: 500,
      totalTickets: 1000,
      startDate: new Date("2024-01-01"),
      endDate: new Date("2024-12-31"),
      isActive: true,
    }).returning();
    
    console.log("Created default raffle:", raffle.title);
  }

  // Check if tickets already exist
  const existingTickets = await db.select().from(tickets);
  
  if (existingTickets.length === 0) {
    console.log("Creating 1000 tickets...");
    
    // Create tickets in batches to avoid memory issues
    const batchSize = 100;
    
    for (let batch = 0; batch < 10; batch++) {
      const ticketsToInsert = [];
      
      for (let i = 1; i <= batchSize; i++) {
        const ticketNumber = batch * batchSize + i;
        
        let status = "available";
        let customerName = null;
        let customerPhone = null;
        let customerState = null;
        let reservedAt = null;
        let purchasedAt = null;
        let totalAmount = null;
        
        // Add some mock sold/reserved tickets for demo
        const rand = Math.random();
        if (rand < 0.089) {
          status = "sold";
          customerName = `Cliente ${ticketNumber}`;
          customerPhone = `+52662${String(ticketNumber).padStart(6, '0')}`;
          customerState = "Sonora";
          purchasedAt = new Date();
          totalAmount = 500;
        } else if (rand < 0.153) {
          status = "reserved";
          customerName = `Reserva ${ticketNumber}`;
          customerPhone = `+52662${String(ticketNumber).padStart(6, '0')}`;
          customerState = "Sonora";
          reservedAt = new Date();
          totalAmount = 500;
        }
        
        ticketsToInsert.push({
          number: ticketNumber,
          customerName,
          customerPhone,
          customerEmail: null,
          customerState,
          status,
          reservedAt,
          purchasedAt,
          totalAmount,
        });
      }
      
      await db.insert(tickets).values(ticketsToInsert);
      console.log(`Created tickets ${batch * batchSize + 1} to ${(batch + 1) * batchSize}`);
    }
    
    console.log("All tickets created successfully!");
  } else {
    console.log("Tickets already exist, skipping ticket creation");
  }
  
  console.log("Database seeding completed!");
}

// Run seeding
seedDatabase().catch(console.error);

export { seedDatabase };