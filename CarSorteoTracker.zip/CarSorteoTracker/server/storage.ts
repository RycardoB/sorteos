import { tickets, raffles, type Ticket, type InsertTicket, type UpdateTicket, type Raffle, type InsertRaffle } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Ticket operations
  getAllTickets(): Promise<Ticket[]>;
  getTicketByNumber(number: number): Promise<Ticket | undefined>;
  getTicketsByStatus(status: string): Promise<Ticket[]>;
  getTicketsByCustomer(phone: string): Promise<Ticket[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(number: number, updates: UpdateTicket): Promise<Ticket | undefined>;
  reserveTickets(numbers: number[], customerData: { name: string; phone: string; email?: string; state?: string }): Promise<Ticket[]>;
  markTicketAsPaid(number: number): Promise<Ticket | undefined>;

  // Raffle operations
  getCurrentRaffle(): Promise<Raffle | undefined>;
  createRaffle(raffle: InsertRaffle): Promise<Raffle>;
  updateRaffle(id: number, updates: Partial<InsertRaffle>): Promise<Raffle | undefined>;

  // Statistics
  getTicketStats(): Promise<{
    total: number;
    available: number;
    reserved: number;
    sold: number;
    revenue: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getAllTickets(): Promise<Ticket[]> {
    return await db.select().from(tickets);
  }

  async getTicketByNumber(number: number): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.number, number));
    return ticket || undefined;
  }

  async getTicketsByStatus(status: string): Promise<Ticket[]> {
    return await db.select().from(tickets).where(eq(tickets.status, status));
  }

  async getTicketsByCustomer(phone: string): Promise<Ticket[]> {
    return await db.select().from(tickets).where(eq(tickets.customerPhone, phone));
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const [ticket] = await db
      .insert(tickets)
      .values({
        ...insertTicket,
        reservedAt: insertTicket.status === "reserved" ? new Date() : null,
        purchasedAt: insertTicket.status === "sold" ? new Date() : null,
      })
      .returning();
    return ticket;
  }

  async updateTicket(number: number, updates: UpdateTicket): Promise<Ticket | undefined> {
    const [ticket] = await db
      .update(tickets)
      .set({
        ...updates,
        reservedAt: updates.status === "reserved" ? new Date() : undefined,
        purchasedAt: updates.status === "sold" ? new Date() : undefined,
      })
      .where(eq(tickets.number, number))
      .returning();
    return ticket || undefined;
  }

  async reserveTickets(numbers: number[], customerData: { name: string; phone: string; email?: string; state?: string }): Promise<Ticket[]> {
    const reservedTickets: Ticket[] = [];
    
    for (const number of numbers) {
      const [ticket] = await db
        .update(tickets)
        .set({
          status: "reserved",
          customerName: customerData.name,
          customerPhone: customerData.phone,
          customerEmail: customerData.email || null,
          customerState: customerData.state || null,
          reservedAt: new Date(),
          totalAmount: 500,
        })
        .where(and(eq(tickets.number, number), eq(tickets.status, "available")))
        .returning();
      
      if (ticket) {
        reservedTickets.push(ticket);
      }
    }
    
    return reservedTickets;
  }

  async markTicketAsPaid(number: number): Promise<Ticket | undefined> {
    const [ticket] = await db
      .update(tickets)
      .set({
        status: "sold",
        purchasedAt: new Date(),
      })
      .where(eq(tickets.number, number))
      .returning();
    return ticket || undefined;
  }

  async getCurrentRaffle(): Promise<Raffle | undefined> {
    const [raffle] = await db.select().from(raffles).where(eq(raffles.isActive, true));
    return raffle || undefined;
  }

  async createRaffle(insertRaffle: InsertRaffle): Promise<Raffle> {
    const [raffle] = await db
      .insert(raffles)
      .values(insertRaffle)
      .returning();
    return raffle;
  }

  async updateRaffle(id: number, updates: Partial<InsertRaffle>): Promise<Raffle | undefined> {
    const [raffle] = await db
      .update(raffles)
      .set(updates)
      .where(eq(raffles.id, id))
      .returning();
    return raffle || undefined;
  }

  async getTicketStats(): Promise<{
    total: number;
    available: number;
    reserved: number;
    sold: number;
    revenue: number;
  }> {
    const allTickets = await this.getAllTickets();
    const available = allTickets.filter(t => t.status === "available").length;
    const reserved = allTickets.filter(t => t.status === "reserved").length;
    const sold = allTickets.filter(t => t.status === "sold").length;
    const revenue = allTickets.filter(t => t.status === "sold").reduce((sum, t) => sum + (t.totalAmount || 0), 0);

    return {
      total: allTickets.length,
      available,
      reserved,
      sold,
      revenue,
    };
  }
}

export const storage = new DatabaseStorage();
