import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTicketSchema, updateTicketSchema, insertRaffleSchema } from "@shared/schema";
import { z } from "zod";
import { uploadMiddleware } from "./upload";

const reserveTicketsSchema = z.object({
  numbers: z.array(z.number()),
  customerData: z.object({
    name: z.string().min(1),
    phone: z.string().min(1),
    email: z.string().email().optional(),
    state: z.string().optional(),
  }),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current raffle
  app.get("/api/raffle", async (req, res) => {
    try {
      const raffle = await storage.getCurrentRaffle();
      if (!raffle) {
        return res.status(404).json({ message: "No active raffle found" });
      }
      res.json(raffle);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch raffle", error });
    }
  });

  // Get all tickets
  app.get("/api/tickets", async (req, res) => {
    try {
      const tickets = await storage.getAllTickets();
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tickets", error });
    }
  });

  // Get ticket by number
  app.get("/api/tickets/:number", async (req, res) => {
    try {
      const number = parseInt(req.params.number);
      const ticket = await storage.getTicketByNumber(number);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      res.json(ticket);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ticket", error });
    }
  });

  // Get tickets by status
  app.get("/api/tickets/status/:status", async (req, res) => {
    try {
      const status = req.params.status;
      const tickets = await storage.getTicketsByStatus(status);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tickets by status", error });
    }
  });

  // Get ticket statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getTicketStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics", error });
    }
  });

  // Reserve tickets
  app.post("/api/tickets/reserve", async (req, res) => {
    try {
      const { numbers, customerData } = reserveTicketsSchema.parse(req.body);
      
      // Check if all numbers are available
      for (const number of numbers) {
        const ticket = await storage.getTicketByNumber(number);
        if (!ticket || ticket.status !== "available") {
          return res.status(400).json({ 
            message: `Ticket number ${number} is not available` 
          });
        }
      }

      const reservedTickets = await storage.reserveTickets(numbers, customerData);
      res.json({ 
        message: "Tickets reserved successfully", 
        tickets: reservedTickets 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to reserve tickets", error });
    }
  });

  // Mark ticket as paid
  app.patch("/api/tickets/:number/paid", async (req, res) => {
    try {
      const number = parseInt(req.params.number);
      const ticket = await storage.markTicketAsPaid(number);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      res.json({ message: "Ticket marked as paid", ticket });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark ticket as paid", error });
    }
  });

  // Update ticket
  app.patch("/api/tickets/:number", async (req, res) => {
    try {
      const number = parseInt(req.params.number);
      const updates = updateTicketSchema.parse(req.body);
      const ticket = await storage.updateTicket(number, updates);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      res.json({ message: "Ticket updated successfully", ticket });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update ticket", error });
    }
  });

  // Get tickets by customer phone
  app.get("/api/customer/:phone/tickets", async (req, res) => {
    try {
      const phone = decodeURIComponent(req.params.phone);
      const tickets = await storage.getTicketsByCustomer(phone);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer tickets", error });
    }
  });

  // Simulate WhatsApp message sending
  app.post("/api/whatsapp/send", async (req, res) => {
    try {
      const { phone, message } = req.body;
      
      // In a real implementation, this would integrate with WhatsApp Business API
      console.log(`WhatsApp message to ${phone}:`, message);
      
      res.json({ 
        success: true, 
        message: "WhatsApp message sent successfully",
        whatsappUrl: `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to send WhatsApp message", error });
    }
  });

  // Upload image endpoint
  app.post("/api/upload-image", uploadMiddleware.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No se proporcionó ningún archivo" });
      }

      // Return the public URL path
      const imageUrl = `/uploads/${req.file.filename}`;
      res.json({ imageUrl });
    } catch (error) {
      console.error("Error uploading image:", error);
      res.status(500).json({ error: "Error al subir la imagen" });
    }
  });

  // Update raffle settings
  app.patch("/api/raffle/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const result = insertRaffleSchema.partial().safeParse(req.body);

      if (!result.success) {
        return res.status(400).json({
          error: "Datos de sorteo inválidos",
          details: result.error.errors
        });
      }

      const raffle = await storage.updateRaffle(id, result.data);
      if (!raffle) {
        return res.status(404).json({ message: "Raffle not found" });
      }
      res.json({ message: "Raffle updated successfully", raffle });
    } catch (error) {
      res.status(500).json({ message: "Failed to update raffle", error });
    }
  });

  // Generate random numbers
  app.post("/api/tickets/random", async (req, res) => {
    try {
      const { count } = req.body;
      const availableTickets = await storage.getTicketsByStatus("available");
      
      if (availableTickets.length < count) {
        return res.status(400).json({ 
          message: `Only ${availableTickets.length} tickets available` 
        });
      }
      
      const shuffled = availableTickets.sort(() => 0.5 - Math.random());
      const randomNumbers = shuffled.slice(0, count).map(t => t.number).sort((a, b) => a - b);
      
      res.json({ numbers: randomNumbers });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate random numbers", error });
    }
  });

  // Send reminders to reserved tickets
  app.post("/api/admin/send-reminders", async (req, res) => {
    try {
      const reservedTickets = await storage.getTicketsByStatus("reserved");
      const reminders = [];
      
      for (const ticket of reservedTickets) {
        if (ticket.customerPhone) {
          const message = `Hola ${ticket.customerName}, tienes el boleto #${ticket.number.toString().padStart(4, '0')} apartado. Completa tu pago para asegurar tu participación en el sorteo.`;
          reminders.push({
            phone: ticket.customerPhone,
            message,
            ticketNumber: ticket.number,
          });
        }
      }
      
      res.json({ 
        message: `Reminders sent to ${reminders.length} customers`,
        reminders 
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to send reminders", error });
    }
  });

  // Verify ticket by number or phone
  app.get("/api/tickets/verify/:identifier", async (req, res) => {
    try {
      const identifier = req.params.identifier;
      let ticket;

      console.log(`Verifying ticket with identifier: ${identifier}`);

      // Check if identifier is a number (ticket number) or phone
      if (/^\d+$/.test(identifier)) {
        const ticketNumber = parseInt(identifier);
        if (ticketNumber >= 1 && ticketNumber <= 1000) {
          // Search by ticket number
          ticket = await storage.getTicketByNumber(ticketNumber);
          console.log(`Searching by ticket number: ${ticketNumber}, found: ${ticket ? 'yes' : 'no'}`);
        } else {
          // Treat as phone number
          const tickets = await storage.getTicketsByCustomer(identifier);
          ticket = tickets.length > 0 ? tickets[0] : null;
          console.log(`Searching by phone (large number): ${identifier}, found: ${tickets.length} tickets`);
        }
      } else {
        // Search by phone number
        const tickets = await storage.getTicketsByCustomer(identifier);
        ticket = tickets.length > 0 ? tickets[0] : null;
        console.log(`Searching by phone: ${identifier}, found: ${tickets.length} tickets`);
      }

      if (ticket) {
        console.log(`Ticket found: #${ticket.number}, status: ${ticket.status}`);
        res.json(ticket);
      } else {
        console.log(`No ticket found for identifier: ${identifier}`);
        res.status(404).json({ error: "Ticket not found" });
      }
    } catch (error) {
      console.error("Error verifying ticket:", error);
      res.status(500).json({ error: "Failed to verify ticket" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
