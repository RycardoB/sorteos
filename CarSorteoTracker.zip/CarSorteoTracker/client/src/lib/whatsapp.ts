export interface WhatsAppMessage {
  phone: string;
  message: string;
}

export const sendWhatsAppMessage = async (data: WhatsAppMessage): Promise<void> => {
  // In a real implementation, this would integrate with WhatsApp Business API
  // For now, we'll simulate the functionality
  
  const { phone, message } = data;
  
  // Clean phone number (remove non-digits)
  const cleanPhone = phone.replace(/\D/g, '');
  
  // Create WhatsApp URL
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  
  // Open WhatsApp in new window
  window.open(whatsappUrl, '_blank');
  
  console.log(`WhatsApp message sent to ${phone}:`, message);
};

export const generateConfirmationMessage = (data: {
  customerName: string;
  numbers: number[];
  total: number;
  phone: string;
}): string => {
  return `¡Hola ${data.customerName}! 

Confirmamos tu selección de números para el sorteo de Toyota Tacoma 2024:

📝 Números: ${data.numbers.map(n => n.toString().padStart(4, '0')).join(', ')}
💰 Total: $${data.total.toLocaleString()} MXN
📱 Teléfono: ${data.phone}

Para completar tu compra, realiza el pago y envíanos el comprobante. 

¡Gracias por participar! 🍀`;
};

export const generateReminderMessage = (data: {
  customerName: string;
  ticketNumber: number;
}): string => {
  return `Hola ${data.customerName}, 

Tienes el boleto #${data.ticketNumber.toString().padStart(4, '0')} apartado para el sorteo de Toyota Tacoma 2024.

Completa tu pago para asegurar tu participación en el sorteo.

¡No pierdas esta oportunidad! 🚗✨`;
};
