export interface TicketData {
  ticketNumbers: number[];
  customerName: string;
  customerPhone: string;
  total: number;
  purchaseDate: Date;
}

export const generatePDF = (ticketData: TicketData): void => {
  // Create a simple HTML template for the ticket
  const ticketHTML = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Boleto Digital - El Chato Sorteos</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .ticket {
                background: linear-gradient(135deg, #22C55E, #16A34A);
                color: white;
                padding: 30px;
                border-radius: 15px;
                max-width: 400px;
                margin: 0 auto;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            }
            .header {
                text-align: center;
                margin-bottom: 20px;
            }
            .title {
                font-size: 24px;
                font-weight: bold;
                margin: 0;
            }
            .subtitle {
                font-size: 14px;
                opacity: 0.9;
                margin: 5px 0;
            }
            .vehicle-image {
                width: 100%;
                height: 150px;
                object-fit: cover;
                border-radius: 10px;
                margin: 20px 0;
            }
            .numbers-section {
                background: rgba(255,255,255,0.2);
                padding: 15px;
                border-radius: 10px;
                margin: 20px 0;
                text-align: center;
            }
            .numbers-title {
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }
            .numbers {
                display: flex;
                flex-wrap: wrap;
                gap: 5px;
                justify-content: center;
            }
            .number {
                background: white;
                color: #22C55E;
                padding: 5px 10px;
                border-radius: 5px;
                font-weight: bold;
                font-size: 14px;
            }
            .info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
                margin-top: 20px;
            }
            .info-item {
                text-align: center;
            }
            .info-label {
                font-size: 12px;
                opacity: 0.8;
            }
            .info-value {
                font-size: 16px;
                font-weight: bold;
            }
            .footer {
                text-align: center;
                margin-top: 20px;
                font-size: 12px;
                opacity: 0.8;
            }
        </style>
    </head>
    <body>
        <div class="ticket">
            <div class="header">
                <h1 class="title">EL CHATO SONORA</h1>
                <p class="subtitle">Sorteo Toyota Tacoma 2024</p>
            </div>
            
            <img src="/assets/image_1750636093510.png" 
                 alt="Toyota Tacoma 2024" class="vehicle-image">
            
            <div class="numbers-section">
                <div class="numbers-title">Números Seleccionados</div>
                <div class="numbers">
                    ${ticketData.ticketNumbers.map(num => 
                        `<span class="number">${num.toString().padStart(4, '0')}</span>`
                    ).join('')}
                </div>
            </div>
            
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Cliente</div>
                    <div class="info-value">${ticketData.customerName}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Teléfono</div>
                    <div class="info-value">${ticketData.customerPhone}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Total Pagado</div>
                    <div class="info-value">$${ticketData.total.toLocaleString()}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Fecha de Compra</div>
                    <div class="info-value">${ticketData.purchaseDate.toLocaleDateString()}</div>
                </div>
            </div>
            
            <div class="footer">
                <p>Conserva este boleto como comprobante de tu participación</p>
                <p>Válido únicamente con pago confirmado</p>
            </div>
        </div>
    </body>
    </html>
  `;

  // Create a new window with the ticket content
  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(ticketHTML);
    printWindow.document.close();
    
    // Wait for content to load, then print
    printWindow.onload = () => {
      printWindow.print();
      printWindow.close();
    };
  } else {
    // Fallback: create a blob and download
    const blob = new Blob([ticketHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `boleto_${ticketData.ticketNumbers.join('_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
};
