import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const checkoutSchema = z.object({
  name: z.string().min(1, "El nombre es requerido"),
  phone: z.string().min(10, "El teléfono debe tener al menos 10 dígitos"),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
  state: z.string().min(1, "El estado es requerido"),
});

const mexicanStates = [
  "Aguascalientes", "Baja California", "Baja California Sur", "Campeche",
  "Chiapas", "Chihuahua", "Coahuila", "Colima", "Durango", "Estado de México",
  "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Michoacán", "Morelos",
  "Nayarit", "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo",
  "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala",
  "Veracruz", "Yucatán", "Zacatecas", "Ciudad de México"
];

type CheckoutForm = z.infer<typeof checkoutSchema>;

interface CheckoutFormProps {
  selectedNumbers: number[];
  onClose: () => void;
  onComplete: (data: any) => void;
}

export default function CheckoutForm({ selectedNumbers, onClose, onComplete }: CheckoutFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const ticketPrice = 500;
  const total = selectedNumbers.length * ticketPrice;

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<CheckoutForm>({
    resolver: zodResolver(checkoutSchema),
  });

  const reserveTicketsMutation = useMutation({
    mutationFn: async (data: CheckoutForm) => {
      return apiRequest("POST", "/api/tickets/reserve", {
        numbers: selectedNumbers,
        customerData: {
          name: data.name,
          phone: data.phone,
          email: data.email || undefined,
          state: data.state,
        },
      });
    },
    onSuccess: async (response, variables) => {
      const data = await response.json();
      
      // Send WhatsApp message
      const message = `¡Hola ${variables.name}! 

Confirmamos tu selección de números para el sorteo de Toyota Tacoma 2024:

📝 Números: ${selectedNumbers.map(n => n.toString().padStart(4, '0')).join(', ')}
💰 Total: $${total.toLocaleString()} MXN
📱 Teléfono: ${variables.phone}
📍 Estado: ${variables.state}

Para completar tu compra, realiza el pago y envíanos el comprobante. 

¡Gracias por participar! 🍀`;

      try {
        const whatsappResponse = await apiRequest("POST", "/api/whatsapp/send", {
          phone: variables.phone,
          message,
        });
        const whatsappData = await whatsappResponse.json();
        
        // Open WhatsApp
        if (whatsappData.whatsappUrl) {
          window.open(whatsappData.whatsappUrl, '_blank');
        }
      } catch (error) {
        console.error("Failed to send WhatsApp message:", error);
      }

      // Show success notification
      toast({
        title: "¡Números Apartados!",
        description: "Revisa tu WhatsApp para continuar con el pago",
        duration: 5000,
      });

      // Complete the process
      onComplete({
        ticketNumbers: selectedNumbers,
        customerName: variables.name,
        customerPhone: variables.phone,
        total,
        purchaseDate: new Date(),
      });
      
      setIsSubmitting(false);
    },
    onError: (error: any) => {
      console.error("Reservation failed:", error);
      toast({
        title: "Error",
        description: "No se pudieron apartar los números. Inténtalo de nuevo.",
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });

  const onSubmit = async (data: CheckoutForm) => {
    setIsSubmitting(true);
    reserveTicketsMutation.mutate(data);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-2xl max-w-2xl w-full">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-800">Información de Compra</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-6 h-6" />
            </Button>
          </div>
          
          <div className="p-6">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name">Nombre Completo *</Label>
                  <Input
                    id="name"
                    {...register("name")}
                    placeholder="Tu nombre completo"
                    className="mt-1"
                  />
                  {errors.name && (
                    <p className="text-sm text-red-600 mt-1">{errors.name.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="phone">Teléfono (WhatsApp) *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    {...register("phone")}
                    placeholder="+52 662 123 4567"
                    className="mt-1"
                  />
                  {errors.phone && (
                    <p className="text-sm text-red-600 mt-1">{errors.phone.message}</p>
                  )}
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="state">Estado *</Label>
                  <Select onValueChange={(value) => setValue("state", value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Selecciona tu estado" />
                    </SelectTrigger>
                    <SelectContent>
                      {mexicanStates.map((state) => (
                        <SelectItem key={state} value={state}>
                          {state}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.state && (
                    <p className="text-sm text-red-600 mt-1">{errors.state.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="email">Email (Opcional)</Label>
                  <Input
                    id="email"
                    type="email"
                    {...register("email")}
                    placeholder="tu@email.com"
                    className="mt-1"
                  />
                  {errors.email && (
                    <p className="text-sm text-red-600 mt-1">{errors.email.message}</p>
                  )}
                </div>
              </div>
              

              
              <Card className="bg-gray-50">
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-2">Resumen de Compra:</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Números seleccionados:</span>
                      <div className="flex flex-wrap gap-1">
                        {selectedNumbers.slice(0, 5).map(num => (
                          <Badge key={num} variant="secondary" className="text-xs">
                            {num.toString().padStart(4, '0')}
                          </Badge>
                        ))}
                        {selectedNumbers.length > 5 && (
                          <Badge variant="secondary" className="text-xs">
                            +{selectedNumbers.length - 5} más
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Cantidad de boletos:</span>
                      <span className="font-medium">{selectedNumbers.length}</span>
                    </div>
                    <div className="flex justify-between items-center text-lg font-bold">
                      <span>Total a pagar:</span>
                      <span className="text-brand-green">${total.toLocaleString()} MXN</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <div className="flex space-x-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onClose}
                  className="flex-1"
                  disabled={isSubmitting}
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-brand-green hover:bg-brand-green-dark text-white"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Procesando...
                    </>
                  ) : (
                    <>
                      <FaWhatsapp className="mr-2" />
                      Confirmar por WhatsApp
                    </>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
