import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Download, Share2, CheckCircle } from "lucide-react";

interface TicketDemoProps {
  onClose: () => void;
}

export default function TicketDemo({ onClose }: TicketDemoProps) {
  const exampleTicketData = {
    ticketNumbers: [123, 456, 789],
    customerName: "María García Rodríguez",
    customerPhone: "+526621234567",
    total: 1500,
    purchaseDate: new Date()
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-2xl max-w-md w-full">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-800">Ejemplo de Boleto Digital</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
          
          <div className="p-6">
            {/* Digital Ticket Design */}
            <Card className="bg-gradient-to-br from-brand-green to-brand-green-dark text-white mb-6 overflow-hidden relative">
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  <h3 className="text-xl font-bold">EL CHATO SONORA</h3>
                  <p className="text-sm opacity-90">Sorteo Toyota Tacoma 2024</p>
                  <div className="flex items-center justify-center mt-2">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    <span className="text-xs">BOLETO VÁLIDO</span>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg p-3 mb-4">
                  <img 
                    src="/assets/image_1750636093510.png"
                    alt="Toyota Tacoma 2024" 
                    className="w-full h-24 object-cover rounded"
                  />
                </div>
                
                <div className="text-center space-y-3">
                  <div className="bg-white bg-opacity-15 rounded-lg p-2">
                    <p className="text-xs opacity-75">CLIENTE</p>
                    <p className="font-bold text-sm">{exampleTicketData.customerName}</p>
                  </div>
                  
                  <div className="bg-white bg-opacity-20 rounded-lg p-3">
                    <p className="text-sm font-bold mb-2">Números Seleccionados:</p>
                    <div className="flex flex-wrap gap-1 justify-center">
                      {exampleTicketData.ticketNumbers.map(num => (
                        <Badge key={num} className="bg-white text-brand-green font-bold px-2 py-1 text-sm">
                          {num.toString().padStart(4, '0')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="bg-white bg-opacity-15 rounded p-2">
                      <p className="opacity-75">TOTAL PAGADO</p>
                      <p className="font-bold text-lg">${exampleTicketData.total.toLocaleString()}</p>
                    </div>
                    <div className="bg-white bg-opacity-15 rounded p-2">
                      <p className="opacity-75">FECHA</p>
                      <p className="font-bold">{exampleTicketData.purchaseDate.toLocaleDateString('es-MX')}</p>
                    </div>
                  </div>
                  
                  <div className="text-xs opacity-75 mt-3">
                    ID: TCK-{Date.now().toString().slice(-6)}
                  </div>
                </div>
                
                {/* Decorative elements - simplified */}
                <div className="absolute top-2 right-2 w-8 h-8 bg-white bg-opacity-20 rounded-full"></div>
                <div className="absolute bottom-2 left-2 w-6 h-6 bg-white bg-opacity-20 rounded-full"></div>
              </CardContent>
            </Card>
            
            <div className="text-center space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <p className="text-sm text-green-800 font-semibold mb-1">
                  ¡Boleto Confirmado!
                </p>
                <p className="text-xs text-green-600">
                  Este boleto se envía automáticamente por WhatsApp y correo electrónico
                </p>
              </div>
              
              <div className="flex space-x-3">
                <Button 
                  className="flex-1 bg-brand-green hover:bg-brand-green-dark text-white"
                  disabled
                >
                  <Download className="w-4 h-4 mr-2" />
                  Descargar PDF
                </Button>
                <Button 
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  disabled
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Compartir
                </Button>
              </div>
              
              <div className="text-xs text-gray-500 p-3 bg-gray-50 rounded-lg text-left">
                <p className="font-semibold mb-2">Características del boleto digital:</p>
                <ul className="space-y-1 text-xs">
                  <li>• Diseño profesional con marca</li>
                  <li>• Imagen del vehículo a sortear</li>
                  <li>• Números destacados en badges llamativos</li>
                  <li>• Información completa del cliente y compra</li>
                  <li>• ID único de identificación</li>
                  <li>• Opciones para descargar PDF y compartir</li>
                  <li>• Envío automático por WhatsApp y email</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}