import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import type { Ticket } from "@shared/schema";

interface TicketGridProps {
  onClose: () => void;
  onProceedToCheckout: (numbers: number[]) => void;
}

export default function TicketGrid({ onClose, onProceedToCheckout }: TicketGridProps) {
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [ticketPrice] = useState(500);

  const { data: tickets, isLoading } = useQuery<Ticket[]>({
    queryKey: ["/api/tickets"],
    refetchInterval: 5000,
  });

  const getTicketStatus = (number: number): string => {
    const ticket = tickets?.find(t => t.number === number);
    return ticket?.status || 'available';
  };

  const toggleNumber = (number: number) => {
    const status = getTicketStatus(number);
    if (status !== 'available') return;

    setSelectedNumbers(prev => 
      prev.includes(number) 
        ? prev.filter(n => n !== number)
        : [...prev, number]
    );
  };

  const getButtonClass = (number: number) => {
    const status = getTicketStatus(number);
    const isSelected = selectedNumbers.includes(number);
    
    if (isSelected) {
      return "ticket-number ticket-selected";
    }
    
    switch (status) {
      case 'sold':
        return "ticket-number ticket-sold";
      case 'reserved':
        return "ticket-number ticket-reserved";
      default:
        return "ticket-number ticket-available";
    }
  };

  const generateTicketGrid = () => {
    const buttons = [];
    for (let i = 1; i <= 1000; i++) {
      const status = getTicketStatus(i);
      buttons.push(
        <button
          key={i}
          onClick={() => toggleNumber(i)}
          disabled={status !== 'available'}
          className={getButtonClass(i)}
        >
          {i.toString().padStart(4, '0')}
        </button>
      );
    }
    return buttons;
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
        <div className="bg-white rounded-2xl p-8 max-w-md">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-green mx-auto"></div>
            <p className="mt-4 text-gray-600">Cargando boletos disponibles...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-2xl max-w-6xl w-full max-h-screen overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-800">Selecciona tus Números</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-6 h-6" />
            </Button>
          </div>
          
          <div className="p-6">
            {/* Legend */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Números Disponibles</h3>
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-brand-green rounded"></div>
                    <span>Disponible</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-yellow-400 rounded"></div>
                    <span>Apartado</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-red-500 rounded"></div>
                    <span>Vendido</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-blue-500 rounded"></div>
                    <span>Seleccionado</span>
                  </div>
                </div>
              </div>
              
              {/* Ticket Grid */}
              <div className="ticket-grid grid mb-6">
                {generateTicketGrid()}
              </div>
              
              {/* Selection Summary */}
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-2">Números Seleccionados:</h4>
                  <div className="flex flex-wrap gap-2 min-h-[2rem] mb-4">
                    {selectedNumbers.length === 0 ? (
                      <span className="text-gray-500">Ningún número seleccionado</span>
                    ) : (
                      selectedNumbers
                        .sort((a, b) => a - b)
                        .map(num => (
                          <Badge key={num} className="bg-blue-100 text-blue-800">
                            {num.toString().padStart(4, '0')}
                          </Badge>
                        ))
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-lg">
                      Total: ${(selectedNumbers.length * ticketPrice).toLocaleString()} MXN
                    </span>
                    <Button
                      onClick={() => onProceedToCheckout(selectedNumbers)}
                      disabled={selectedNumbers.length === 0}
                      className="bg-brand-red hover:bg-red-700 text-white"
                    >
                      Continuar con la Compra
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
