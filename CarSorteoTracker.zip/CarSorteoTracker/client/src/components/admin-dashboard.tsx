import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Chart, registerables, type ChartConfiguration } from "chart.js";

// Register Chart.js components
Chart.register(...registerables);

interface AdminDashboardProps {
  stats?: {
    total: number;
    available: number;
    reserved: number;
    sold: number;
    revenue: number;
  };
}

export default function AdminDashboard({ stats }: AdminDashboardProps) {
  const statusChartRef = useRef<HTMLCanvasElement>(null);
  const salesChartRef = useRef<HTMLCanvasElement>(null);
  const statusChartInstance = useRef<Chart | null>(null);
  const salesChartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (!stats) return;

    // Cleanup existing charts
    if (statusChartInstance.current) {
      statusChartInstance.current.destroy();
    }
    if (salesChartInstance.current) {
      salesChartInstance.current.destroy();
    }

    // Create Ticket Status Chart
    if (statusChartRef.current) {
      const ctx = statusChartRef.current.getContext('2d');
      if (ctx) {
        const statusConfig: ChartConfiguration = {
          type: 'doughnut',
          data: {
            labels: ['Vendidos', 'Apartados', 'Disponibles'],
            datasets: [{
              data: [stats.sold, stats.reserved, stats.available],
              backgroundColor: [
                'hsl(142, 76%, 36%)', // brand-green
                'hsl(45, 93%, 47%)',  // yellow
                'hsl(220, 14%, 56%)'  // gray
              ],
              borderWidth: 2,
              borderColor: '#fff'
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  padding: 20,
                  usePointStyle: true,
                }
              }
            }
          }
        };

        statusChartInstance.current = new Chart(ctx, statusConfig);
      }
    }

    // Create Sales Chart (mock data for demo)
    if (salesChartRef.current) {
      const ctx = salesChartRef.current.getContext('2d');
      if (ctx) {
        const salesConfig: ChartConfiguration = {
          type: 'line',
          data: {
            labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
            datasets: [{
              label: 'Boletos Vendidos',
              data: [12, 19, 8, 15, 22, 18, 25],
              borderColor: 'hsl(142, 76%, 36%)',
              backgroundColor: 'hsla(142, 76%, 36%, 0.1)',
              tension: 0.4,
              fill: true,
              pointBackgroundColor: 'hsl(142, 76%, 36%)',
              pointBorderColor: '#fff',
              pointBorderWidth: 2,
              pointRadius: 5,
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'hsl(220, 14%, 90%)'
                }
              },
              x: {
                grid: {
                  display: false
                }
              }
            }
          }
        };

        salesChartInstance.current = new Chart(ctx, salesConfig);
      }
    }

    // Cleanup function
    return () => {
      if (statusChartInstance.current) {
        statusChartInstance.current.destroy();
      }
      if (salesChartInstance.current) {
        salesChartInstance.current.destroy();
      }
    };
  }, [stats]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Estado de Boletos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <canvas ref={statusChartRef}></canvas>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Ventas por Día</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <canvas ref={salesChartRef}></canvas>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
