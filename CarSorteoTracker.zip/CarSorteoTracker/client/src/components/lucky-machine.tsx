import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Shuffle, Sparkles, CreditCard } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface LuckyMachineProps {
  onClose: () => void;
  onProceedToCheckout: (numbers: number[]) => void;
}

export default function LuckyMachine({ onClose, onProceedToCheckout }: LuckyMachineProps) {
  const [ticketCount, setTicketCount] = useState<number>(1);
  const [generatedNumbers, setGeneratedNumbers] = useState<number[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const generateRandomMutation = useMutation({
    mutationFn: async (count: number) => {
      const response = await fetch("/api/tickets/random", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ count }),
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("API response:", data);
      return data;
    },
    onSuccess: (data) => {
      if (data && data.numbers && Array.isArray(data.numbers)) {
        setGeneratedNumbers(data.numbers);
      } else {
        console.error("Invalid data format received:", data);
        toast({
          title: "Error",
          description: "Formato de datos inválido. Inténtalo de nuevo.",
          variant: "destructive",
        });
      }
      setIsGenerating(false);
    },
    onError: (error) => {
      console.error("Error generating numbers:", error);
      toast({
        title: "Error",
        description: "No se pudieron generar los números. Inténtalo de nuevo.",
        variant: "destructive",
      });
      setIsGenerating(false);
    },
  });

  const handleGenerate = () => {
    if (ticketCount < 1 || ticketCount > 50) {
      toast({
        title: "Error",
        description: "Puedes elegir entre 1 y 50 boletos",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setGeneratedNumbers([]);
    
    setTimeout(() => {
      generateRandomMutation.mutate(ticketCount);
    }, 500);
  };

  const handleProceedToCheckout = () => {
    onProceedToCheckout(generatedNumbers);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-[1000]">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-gray-900 shadow-xl">
        <CardHeader className="bg-gradient-to-r from-brand-green to-green-600 text-white text-center relative p-6">
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-4 top-4 text-white hover:bg-white/20"
            onClick={onClose}
          >
            <X className="w-4 h-4" />
          </Button>
          <CardTitle className="text-2xl font-bold">
            Máquina de la Suerte
          </CardTitle>
          <p className="text-green-100 mt-2">¡La fortuna favorece a los audaces!</p>
        </CardHeader>

        <CardContent className="p-6 space-y-6">
          {/* Selector de cantidad */}
          <div className="text-center space-y-4">
            <div className="max-w-md mx-auto">
              <Label htmlFor="ticketCount" className="text-lg font-semibold">
                ¿Cuántos boletos quieres?
              </Label>
              <div className="flex items-center space-x-4 mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setTicketCount(Math.max(1, ticketCount - 1))}
                  disabled={isGenerating}
                >
                  -
                </Button>
                <Input
                  id="ticketCount"
                  type="number"
                  min="1"
                  max="50"
                  value={ticketCount}
                  onChange={(e) => setTicketCount(parseInt(e.target.value) || 1)}
                  className="text-center text-2xl font-bold w-24"
                  disabled={isGenerating}
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setTicketCount(Math.min(50, ticketCount + 1))}
                  disabled={isGenerating}
                >
                  +
                </Button>
              </div>
              <p className="text-sm text-gray-500 mt-2">Máximo 50 boletos por sorteo</p>
            </div>
            
            <Button
              onClick={handleGenerate}
              disabled={isGenerating || generateRandomMutation.isPending}
              className="mt-6 bg-gradient-to-r from-brand-green to-green-600 hover:from-brand-green-dark hover:to-green-700 text-white font-bold py-3 px-8 rounded-xl text-lg"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Generando...
                </>
              ) : (
                <>
                  <Shuffle className="w-5 h-5 mr-2" />
                  Generar Números
                </>
              )}
            </Button>
          </div>

          {/* Área de números generados */}
          <div className="text-center space-y-4">
            <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-xl border border-gray-200 dark:border-gray-700 min-h-[120px] flex items-center justify-center">
              {isGenerating ? (
                <div className="flex flex-col items-center space-y-3">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
                  <p className="text-green-700 dark:text-green-300 font-medium">
                    Generando números...
                  </p>
                </div>
              ) : generatedNumbers && generatedNumbers.length > 0 ? (
                <div className="space-y-4 w-full">
                  <p className="text-lg font-bold text-green-700 dark:text-green-300">
                    ¡Tus números de la suerte!
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {generatedNumbers.map((number, index) => (
                      <Badge
                        key={index}
                        className="bg-gradient-to-r from-brand-green to-green-600 text-white text-lg px-4 py-2 font-bold shadow-lg transform hover:scale-105 transition-transform"
                      >
                        {number.toString().padStart(4, '0')}
                      </Badge>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center text-gray-500 dark:text-gray-400">
                  <Sparkles className="w-16 h-16 mx-auto mb-2 opacity-50" />
                  <p>Aquí aparecerán tus números de la suerte</p>
                </div>
              )}
            </div>
          </div>

          {/* Resumen y botones */}
          {generatedNumbers && generatedNumbers.length > 0 && (
            <div className="text-center space-y-4">
              <div className="bg-green-50 dark:bg-green-900 p-4 rounded-lg border border-green-200 dark:border-green-700">
                <h4 className="font-bold text-green-800 dark:text-green-200 mb-2">
                  Resumen de compra
                </h4>
                <p className="text-green-600 dark:text-green-300">
                  {generatedNumbers.length} boleto{generatedNumbers.length !== 1 ? 's' : ''}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                  $500 por boleto
                </p>
                <p className="text-xl font-bold text-green-700 dark:text-green-300">
                  Total: ${(generatedNumbers.length * 500).toLocaleString()}
                </p>
              </div>
              
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={handleGenerate}
                  className="flex-1"
                  disabled={isGenerating}
                >
                  <Shuffle className="w-4 h-4 mr-2" />
                  Generar Otros
                </Button>
                <Button
                  onClick={handleProceedToCheckout}
                  disabled={isGenerating || generatedNumbers.length === 0}
                  className="flex-1 bg-gradient-to-r from-brand-green to-green-600 hover:from-brand-green-dark hover:to-green-700 text-white px-8 py-3 rounded-lg font-bold"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Continuar
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}