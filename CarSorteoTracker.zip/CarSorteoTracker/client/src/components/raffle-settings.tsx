import { useState, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Upload, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Raffle } from "@shared/schema";

const raffleSettingsSchema = z.object({
  title: z.string().min(1, "El título es requerido"),
  description: z.string().optional(),
  vehicleModel: z.string().min(1, "El modelo es requerido"),
  vehicleYear: z.number().min(1900).max(2030),
  vehicleImage: z.string().optional(),
  ticketPrice: z.number().min(1, "El precio debe ser mayor a 0"),
  totalTickets: z.number().min(1, "El total debe ser mayor a 0"),
});

type RaffleSettingsForm = z.infer<typeof raffleSettingsSchema>;

interface RaffleSettingsProps {
  onClose: () => void;
}

export default function RaffleSettings({ onClose }: RaffleSettingsProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  const { data: raffle } = useQuery<Raffle>({
    queryKey: ["/api/raffle"],
  });

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<RaffleSettingsForm>({
    resolver: zodResolver(raffleSettingsSchema),
    defaultValues: {
      title: raffle?.title || "",
      description: raffle?.description || "",
      vehicleModel: raffle?.vehicleModel || "",
      vehicleYear: raffle?.vehicleYear || 2024,
      vehicleImage: raffle?.vehicleImage || "",
      ticketPrice: raffle?.ticketPrice || 500,
      totalTickets: raffle?.totalTickets || 1000,
    },
  });

  // Set image preview when raffle data loads
  if (raffle?.vehicleImage && !imagePreview) {
    setImagePreview(raffle.vehicleImage);
  }

  const updateRaffleMutation = useMutation({
    mutationFn: async (data: RaffleSettingsForm) => {
      return apiRequest("PATCH", `/api/raffle/${raffle?.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/raffle"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Éxito",
        description: "Configuración del sorteo actualizada",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo actualizar la configuración",
        variant: "destructive",
      });
    },
  });

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Por favor selecciona un archivo de imagen válido",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Error",
        description: "El archivo es demasiado grande. Máximo 5MB permitido",
        variant: "destructive",
      });
      return;
    }

    setIsUploadingImage(true);

    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Error al subir la imagen');
      }

      const result = await response.json();
      
      // Update form and preview
      setValue('vehicleImage', result.imageUrl);
      setImagePreview(result.imageUrl);

      toast({
        title: "Éxito",
        description: "Imagen subida correctamente",
      });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: "Error",
        description: "Error al subir la imagen. Inténtalo de nuevo",
        variant: "destructive",
      });
    } finally {
      setIsUploadingImage(false);
    }
  };

  const onSubmit = (data: RaffleSettingsForm) => {
    updateRaffleMutation.mutate(data);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-2xl max-w-2xl w-full">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-800">Configuración del Sorteo</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-6 h-6" />
            </Button>
          </div>
          
          <div className="p-6">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="title">Título del Sorteo *</Label>
                  <Input
                    id="title"
                    {...register("title")}
                    placeholder="Toyota Tacoma 2024"
                    className="mt-1"
                  />
                  {errors.title && (
                    <p className="text-sm text-red-600 mt-1">{errors.title.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="vehicleModel">Modelo del Vehículo *</Label>
                  <Input
                    id="vehicleModel"
                    {...register("vehicleModel")}
                    placeholder="Toyota Tacoma"
                    className="mt-1"
                  />
                  {errors.vehicleModel && (
                    <p className="text-sm text-red-600 mt-1">{errors.vehicleModel.message}</p>
                  )}
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  {...register("description")}
                  placeholder="Sorteo de Toyota Tacoma 2024 completamente nueva"
                  className="mt-1"
                />
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="vehicleYear">Año del Vehículo *</Label>
                  <Input
                    id="vehicleYear"
                    type="number"
                    {...register("vehicleYear", { valueAsNumber: true })}
                    placeholder="2024"
                    className="mt-1"
                  />
                  {errors.vehicleYear && (
                    <p className="text-sm text-red-600 mt-1">{errors.vehicleYear.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="ticketPrice">Precio del Boleto (MXN) *</Label>
                  <Input
                    id="ticketPrice"
                    type="number"
                    {...register("ticketPrice", { valueAsNumber: true })}
                    placeholder="500"
                    className="mt-1"
                  />
                  {errors.ticketPrice && (
                    <p className="text-sm text-red-600 mt-1">{errors.ticketPrice.message}</p>
                  )}
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="totalTickets">Total de Boletos *</Label>
                  <Input
                    id="totalTickets"
                    type="number"
                    {...register("totalTickets", { valueAsNumber: true })}
                    placeholder="1000"
                    className="mt-1"
                  />
                  {errors.totalTickets && (
                    <p className="text-sm text-red-600 mt-1">{errors.totalTickets.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="vehicleImage">Imagen del Vehículo</Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id="vehicleImage"
                      {...register("vehicleImage")}
                      placeholder="URL de imagen o sube un archivo"
                      className="flex-1"
                    />
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploadingImage}
                      className="px-3"
                    >
                      {isUploadingImage ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Upload className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  {imagePreview && (
                    <div className="mt-2 relative">
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="w-full h-32 object-cover rounded-md border"
                      />
                      <div className="absolute top-1 right-1">
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={() => {
                            setImagePreview("");
                            setValue("vehicleImage", "");
                          }}
                          className="h-6 w-6 p-0"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                  {errors.vehicleImage && (
                    <p className="text-sm text-red-600 mt-1">{errors.vehicleImage.message}</p>
                  )}
                </div>
              </div>
              
              <div className="flex space-x-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onClose}
                  className="flex-1"
                  disabled={updateRaffleMutation.isPending}
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-brand-green hover:bg-brand-green-dark text-white"
                  disabled={updateRaffleMutation.isPending}
                >
                  {updateRaffleMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Guardando...
                    </>
                  ) : (
                    "Guardar Cambios"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}