import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Search, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import type { Ticket } from "@shared/schema";

interface TicketVerifierProps {
  onClose: () => void;
}

export default function TicketVerifier({ onClose }: TicketVerifierProps) {
  const [searchInput, setSearchInput] = useState("");
  const [searchedNumber, setSearchedNumber] = useState<string | number | null>(null);

  const { data: ticket, isLoading, error } = useQuery<Ticket | null>({
    queryKey: ["/api/tickets/verify", searchedNumber],
    queryFn: async () => {
      console.log('Fetching ticket for:', searchedNumber);
      const response = await fetch(`/api/tickets/verify/${searchedNumber}`);
      console.log('Response status:', response.status);
      
      if (!response.ok) {
        if (response.status === 404) {
          console.log('Ticket not found (404)');
          return null;
        }
        const errorText = await response.text();
        console.error('API Error:', errorText);
        throw new Error('Failed to verify ticket');
      }
      
      const data = await response.json();
      console.log('Ticket data received:', data);
      return data;
    },
    enabled: searchedNumber !== null,
    retry: false,
  });

  const handleVerify = () => {
    const input = searchInput.trim();
    if (!input) {
      return;
    }
    
    // Check if it's a number (ticket number) or phone
    if (/^\d+$/.test(input)) {
      const number = parseInt(input);
      // If it's a valid ticket number (1-1000) use as is, otherwise treat as phone
      setSearchedNumber(number);
    } else {
      // For phone numbers or mixed input, use the string directly
      setSearchedNumber(input as any);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleVerify();
    }
  };

  const getStatusBadge = (status: string) => {
    if (status === 'sold') {
      return <Badge className="bg-green-500 text-white">PAGADO</Badge>;
    } else if (status === 'reserved') {
      return <Badge className="bg-yellow-500 text-white">RESERVADO</Badge>;
    } else {
      return <Badge className="bg-gray-500 text-white">DISPONIBLE</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    if (status === 'sold') {
      return <CheckCircle className="w-5 h-5 text-green-500" />;
    } else if (status === 'reserved') {
      return <AlertCircle className="w-5 h-5 text-yellow-500" />;
    } else {
      return <CheckCircle className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="bg-black text-white text-center relative">
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-4 top-4 text-white hover:bg-white hover:bg-opacity-20"
            onClick={onClose}
          >
            <X className="w-4 h-4" />
          </Button>
          <CardTitle className="text-2xl font-bold">
            VERIFICADOR DE BOLETOS
          </CardTitle>
          <p className="text-brand-green text-lg font-semibold">
            Para el TOYOTA TACOMA 2025
          </p>
        </CardHeader>

        <CardContent className="p-6">
          {/* Instructions and Search */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="w-0 h-0 border-l-[12px] border-r-[12px] border-b-[20px] border-l-transparent border-r-transparent border-b-brand-green mr-3"></div>
              <p className="text-lg">
                Introduce tu <strong>BOLETO ó CELULAR</strong> y haz click en "Verificar"
              </p>
            </div>

            <div className="flex justify-center items-center space-x-4 max-w-md mx-auto">
              <Input
                type="text"
                placeholder="Escribe Boleto ó Celular"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1 h-12 text-center text-lg border-2 border-gray-300 focus:border-brand-green"
              />
              <Button
                onClick={handleVerify}
                disabled={!searchInput.trim() || isLoading}
                className="bg-brand-green hover:bg-brand-green-dark text-white px-8 py-3 text-lg font-semibold h-12"
              >
                {isLoading ? (
                  "Verificando..."
                ) : (
                  <>
                    <Search className="w-5 h-5 mr-2" />
                    Verificar
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Results Table */}
          {searchedNumber !== null && (
            <div className="mt-8">
              <div className="bg-black text-white grid grid-cols-6 gap-4 p-4 text-center font-bold">
                <div>Número</div>
                <div>Oportunidades</div>
                <div>Nombre</div>
                <div>Apellido</div>
                <div>Estado</div>
                <div>Pagado</div>
              </div>

              {isLoading ? (
                <div className="border-2 border-gray-200 p-8 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-green mx-auto mb-4"></div>
                  <p>Verificando boleto...</p>
                </div>
              ) : error || !ticket ? (
                <div className="border-2 border-gray-200 p-8 text-center">
                  <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                  <p className="text-lg font-semibold text-red-600">
                    Boleto no encontrado
                  </p>
                  <p className="text-gray-600 mt-2">
                    El identificador "{searchedNumber}" no está registrado en el sistema
                  </p>
                </div>
              ) : (
                <div className="border-2 border-gray-200">
                  <div className="grid grid-cols-6 gap-4 p-4 text-center items-center bg-white hover:bg-gray-50">
                    <div className="font-bold text-lg">
                      {ticket.number.toString().padStart(3, '0')}
                    </div>
                    <div className="flex justify-center">
                      {getStatusIcon(ticket.status)}
                    </div>
                    <div className="font-semibold">
                      {ticket.status === 'sold' || ticket.status === 'reserved' 
                        ? (ticket.customerName || '-')
                        : '-'
                      }
                    </div>
                    <div className="font-semibold">
                      {ticket.status === 'sold' || ticket.status === 'reserved'
                        ? (ticket.customerName ? ticket.customerName.split(' ').slice(1).join(' ') || '-' : '-')
                        : '-'
                      }
                    </div>
                    <div>
                      {ticket.status === 'sold' || ticket.status === 'reserved'
                        ? (ticket.customerState || 'SONORA')
                        : '-'
                      }
                    </div>
                    <div>
                      {getStatusBadge(ticket.status)}
                    </div>
                  </div>
                </div>
              )}

              {/* Additional Info */}
              {ticket && (
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-bold text-lg mb-3">Información Adicional</h3>
                  
                  {/* Mostrar información completa solo si está pagado */}
                  {ticket.status === 'sold' ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <strong>Teléfono:</strong> {ticket.customerPhone || 'No registrado'}
                      </div>
                      <div>
                        <strong>Email:</strong> {ticket.customerEmail || 'No registrado'}
                      </div>
                      <div>
                        <strong>Fecha de Compra:</strong> {
                          ticket.purchasedAt 
                            ? new Date(ticket.purchasedAt).toLocaleDateString('es-MX')
                            : 'No registrada'
                        }
                      </div>
                      <div>
                        <strong>Estado del Boleto:</strong> Pagado y confirmado
                      </div>
                      <div className="md:col-span-2">
                        <div className="p-3 bg-green-100 border border-green-300 rounded-lg">
                          <p className="text-green-800 font-semibold">
                            ✅ Boleto válido y pagado - Participante confirmado en el sorteo
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : ticket.status === 'reserved' ? (
                    /* Información limitada para boletos reservados */
                    <div className="grid grid-cols-1 gap-4 text-sm">
                      <div>
                        <strong>Estado del Boleto:</strong> Reservado (Pendiente de pago)
                      </div>
                      <div>
                        <strong>Fecha de Reserva:</strong> {
                          ticket.reservedAt 
                            ? new Date(ticket.reservedAt).toLocaleDateString('es-MX')
                            : 'No registrada'
                        }
                      </div>
                      <div className="p-3 bg-yellow-100 border border-yellow-300 rounded-lg">
                        <p className="text-yellow-800 font-semibold">
                          ⏰ Boleto reservado - Debe completar el pago para confirmar su participación
                        </p>
                      </div>
                    </div>
                  ) : false ? (
                    /* Boleto vendido pero no pagado */
                    <div className="grid grid-cols-1 gap-4 text-sm">
                      <div>
                        <strong>Estado del Boleto:</strong> Vendido pero no pagado
                      </div>
                      <div className="p-3 bg-red-100 border border-red-300 rounded-lg">
                        <p className="text-red-800 font-semibold">
                          ❌ Boleto no válido - El pago no ha sido confirmado
                        </p>
                      </div>
                    </div>
                  ) : (
                    /* Boleto disponible */
                    <div className="grid grid-cols-1 gap-4 text-sm">
                      <div>
                        <strong>Estado del Boleto:</strong> Disponible para compra
                      </div>
                      <div className="p-3 bg-blue-100 border border-blue-300 rounded-lg">
                        <p className="text-blue-800 font-semibold">
                          🎫 Boleto disponible - Puede adquirirse para participar en el sorteo
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Search by Phone Instructions */}
          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <h3 className="font-bold text-blue-800 mb-2">Búsqueda por Teléfono</h3>
            <p className="text-blue-700 text-sm">
              También puedes buscar introduciendo tu número de teléfono para ver todos tus boletos registrados.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}