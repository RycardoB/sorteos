import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Download, Share2 } from "lucide-react";
import { generatePDF } from "@/lib/pdf-generator";

interface DigitalTicketProps {
  ticketData: {
    ticketNumbers: number[];
    customerName: string;
    customerPhone: string;
    total: number;
    purchaseDate: Date;
  };
  onClose: () => void;
}

export default function DigitalTicket({ ticketData, onClose }: DigitalTicketProps) {
  const handleDownload = () => {
    generatePDF(ticketData);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Mi Boleto - El Chato Sorteos',
          text: `Mira mi boleto para el sorteo de Toyota Tacoma 2024. Números: ${ticketData.ticketNumbers.map(n => n.toString().padStart(4, '0')).join(', ')}`,
          url: window.location.href
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      // Fallback: copy to clipboard
      const text = `Mi boleto para el sorteo de Toyota Tacoma 2024. Números: ${ticketData.ticketNumbers.map(n => n.toString().padStart(4, '0')).join(', ')}`;
      navigator.clipboard.writeText(text);
      alert('Información del boleto copiada al portapapeles');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-2xl max-w-md w-full">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-800">Tu Boleto Digital</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
          
          <div className="p-6">
            {/* Digital Ticket Design */}
            <Card className="bg-gradient-to-br from-brand-green to-brand-green-dark text-white mb-6 overflow-hidden">
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  <h3 className="text-xl font-bold">EL CHATO SONORA</h3>
                  <p className="text-sm opacity-90">Sorteo Toyota Tacoma 2024</p>
                </div>
                
                <img 
                  src="/assets/image_1750636093510.png"
                  alt="Toyota Tacoma 2024" 
                  className="w-full h-32 object-cover rounded-lg mb-4"
                />
                
                <div className="text-center space-y-2">
                  <p className="text-sm opacity-90">Cliente: {ticketData.customerName}</p>
                  <div className="bg-white bg-opacity-20 rounded-lg p-3">
                    <p className="text-lg font-bold mb-2">
                      Números Seleccionados:
                    </p>
                    <div className="flex flex-wrap gap-1 justify-center">
                      {ticketData.ticketNumbers.map(num => (
                        <Badge key={num} className="bg-white text-brand-green font-bold">
                          {num.toString().padStart(4, '0')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm mt-4">
                    <div>
                      <p className="opacity-75">Total Pagado:</p>
                      <p className="font-bold text-lg">${ticketData.total.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="opacity-75">Fecha de Compra:</p>
                      <p className="font-bold">{ticketData.purchaseDate.toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>
                
                {/* Decorative pattern - simplified to avoid DOM issues */}
                <div className="absolute top-2 right-2 w-8 h-8 bg-white bg-opacity-20 rounded-full"></div>
                <div className="absolute bottom-2 left-2 w-6 h-6 bg-white bg-opacity-20 rounded-full"></div>
              </CardContent>
            </Card>
            
            <div className="text-center space-y-4">
              <p className="text-sm text-gray-600">
                Guarda este boleto como comprobante de tu participación
              </p>
              
              <div className="flex space-x-3">
                <Button 
                  onClick={handleDownload}
                  className="flex-1 bg-brand-green hover:bg-brand-green-dark text-white"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Descargar PDF
                </Button>
                <Button 
                  onClick={handleShare}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Compartir
                </Button>
              </div>
              
              <div className="text-xs text-gray-500 mt-4 p-3 bg-gray-50 rounded-lg">
                <p className="font-semibold mb-1">Importante:</p>
                <p>Este boleto es válido únicamente si el pago ha sido confirmado. 
                Conserva este comprobante hasta el día del sorteo.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
