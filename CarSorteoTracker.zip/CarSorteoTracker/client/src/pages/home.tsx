import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Car, Phone, Mail, MapPin, CheckCircle, MousePointer, CreditCard, Sparkles, Search } from "lucide-react";
import { FaWhatsapp, FaBars, FaTimes } from "react-icons/fa";
import TicketGrid from "@/components/ticket-grid";
import CheckoutForm from "@/components/checkout-form";
import DigitalTicket from "@/components/digital-ticket";
import LuckyMachine from "@/components/lucky-machine";
import TicketVerifier from "@/components/ticket-verifier";
import TicketDemo from "@/components/ticket-demo";
import { Link } from "wouter";
import type { Raffle } from "@shared/schema";

export default function Home() {
  const [activeModal, setActiveModal] = useState<'none' | 'ticketGrid' | 'luckyMachine' | 'checkout' | 'digitalTicket' | 'verifier' | 'demo'>('none');
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const [ticketData, setTicketData] = useState<any>(null);

  const { data: raffle } = useQuery<Raffle>({
    queryKey: ["/api/raffle"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const handleTicketSelection = (numbers: number[]) => {
    setSelectedNumbers(numbers);
  };

  const closeModal = () => {
    setActiveModal('none');
  };

  const handleProceedToCheckout = (numbers: number[]) => {
    setSelectedNumbers(numbers);
    setActiveModal('checkout');
  };

  const handleCheckoutComplete = (data: any) => {
    setActiveModal('none');
    setSelectedNumbers([]);
    
    // Small delay to ensure DOM cleanup before showing ticket
    setTimeout(() => {
      setTicketData(data);
      setActiveModal('digitalTicket');
    }, 150);
  };

  const toggleFAQ = (index: number) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  const faqItems = [
    {
      question: "¿Cuándo es el sorteo?",
      answer: "El sorteo se realizará cuando se vendan todos los boletos disponibles, con fecha límite el 31 de diciembre de 2024."
    },
    {
      question: "¿Qué métodos de pago aceptan?",
      answer: "Aceptamos transferencias bancarias, depósitos en efectivo, pagos por WhatsApp y tarjetas de crédito/débito."
    },
    {
      question: "¿Cómo recibo mi boleto?",
      answer: "Una vez confirmado tu pago, recibirás tu boleto digital por WhatsApp y correo electrónico."
    },
    {
      question: "¿Puedo cambiar mis números después de la compra?",
      answer: "Los números no pueden ser cambiados una vez confirmada la compra y el pago."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gray-800 shadow-lg sticky top-0 z-40">
        <nav className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-brand-green rounded-full flex items-center justify-center">
                <Car className="text-white text-xl" />
              </div>
              <div>
                <h1 className="text-white font-bold text-xl">BM Sorteos</h1>
                <p className="text-green-400 text-xs">SONORA</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <a href="#inicio" className="text-white hover:text-brand-green transition-colors">Inicio</a>
              <a href="#preguntas" className="text-white hover:text-brand-green transition-colors">Preguntas Frecuentes</a>
              <a href="#contacto" className="text-white hover:text-brand-green transition-colors">Contacto</a>
              <a href="#metodos" className="text-white hover:text-brand-green transition-colors">Métodos de Pago</a>
              <div className="flex space-x-2">
                <Button 
                  onClick={() => setActiveModal('ticketGrid')}
                  className="bg-brand-red hover:bg-red-700 text-white"
                >
                  Elegir Números
                </Button>
                <Button 
                  onClick={() => setActiveModal('luckyMachine')}
                  className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Suerte
                </Button>
              </div>
              <Link href="/admin">
                <Button className="bg-brand-green hover:bg-brand-green-dark text-white">
                  Admin
                </Button>
              </Link>
            </div>

            <Button 
              variant="ghost" 
              size="sm"
              className="md:hidden text-white"
              onClick={() => setShowMobileMenu(!showMobileMenu)}
            >
              {showMobileMenu ? <FaTimes className="text-xl" /> : <FaBars className="text-xl" />}
            </Button>
          </div>

          {/* Mobile Menu */}
          {showMobileMenu && (
            <div className="md:hidden mt-4 pb-4">
              <div className="flex flex-col space-y-3">
                <a href="#inicio" className="text-white hover:text-brand-green transition-colors">Inicio</a>
                <a href="#preguntas" className="text-white hover:text-brand-green transition-colors">Preguntas Frecuentes</a>
                <a href="#contacto" className="text-white hover:text-brand-green transition-colors">Contacto</a>
                <a href="#metodos" className="text-white hover:text-brand-green transition-colors">Métodos de Pago</a>
                <Button 
                  onClick={() => setActiveModal('ticketGrid')}
                  className="bg-brand-red hover:bg-red-700 text-white text-left justify-start"
                >
                  Elegir Números
                </Button>
                <Button 
                  onClick={() => setActiveModal('luckyMachine')}
                  className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white text-left justify-start"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Máquina de la Suerte
                </Button>
              </div>
            </div>
          )}
        </nav>
      </header>

      {/* Hero Section */}
      <section id="inicio" className="relative bg-gradient-to-br from-gray-900 to-gray-800 text-white py-16">
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        ></div>
        
        <div className="relative container mx-auto px-4 text-center">
          <div className="bg-brand-red inline-block px-8 py-3 rounded-full mb-8">
            <h2 className="text-xl font-bold">- LISTA DE DISPONIBLES -</h2>
          </div>
          
          <div className="max-w-4xl mx-auto bg-white bg-opacity-95 rounded-2xl p-8 text-gray-800">
            <img 
              src={raffle?.vehicleImage || "/assets/image_1750636093510.png"}
              alt={raffle?.title || "Toyota Tacoma 2024"} 
              className="w-full h-64 md:h-96 object-cover rounded-xl mb-6 shadow-lg"
            />
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-3xl font-bold text-brand-green mb-4">
                  {raffle?.title || "Toyota Tacoma 2024"}
                </h3>
                <div className="space-y-3 text-left">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="text-brand-green w-5 h-5" />
                    <span>Motor V6 3.5L</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="text-brand-green w-5 h-5" />
                    <span>Transmisión Automática</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="text-brand-green w-5 h-5" />
                    <span>4x4 Todo Terreno</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="text-brand-green w-5 h-5" />
                    <span>Totalmente Nueva</span>
                  </div>
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-gradient-to-r from-brand-green to-brand-green-dark text-white p-6 rounded-xl mb-4">
                  <p className="text-lg">Precio del Boleto</p>
                  <p className="text-4xl font-bold">${raffle?.ticketPrice || 500}</p>
                  <p className="text-sm opacity-90">MXN</p>
                </div>
                
                <div className="bg-gray-100 p-3 rounded-lg">
                  <p className="text-sm text-gray-600 mb-2">¡Participa y gana!</p>
                  <p className="text-lg font-bold text-brand-green">Sorteo Toyota Tacoma 2024</p>
                </div>
                
                <div className="space-y-3 mt-6">
                  <Button 
                    onClick={() => setActiveModal('ticketGrid')}
                    className="w-full bg-brand-red hover:bg-red-700 text-white font-bold py-4 px-8 rounded-xl transform hover:scale-105 transition-all duration-200"
                  >
                    ELEGIR MIS NÚMEROS
                  </Button>
                  
                  <Button 
                    onClick={() => setActiveModal('luckyMachine')}
                    className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-bold py-4 px-8 rounded-xl transform hover:scale-105 transition-all duration-200"
                  >
                    <Sparkles className="w-5 h-5 mr-2" />
                    MÁQUINA DE LA SUERTE
                  </Button>
                  
                  <Button 
                    onClick={() => setActiveModal('verifier')}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-8 rounded-xl transform hover:scale-105 transition-all duration-200"
                  >
                    <Search className="w-5 h-5 mr-2" />
                    VERIFICAR BOLETO
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">¿Cómo Funciona?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-brand-green rounded-full flex items-center justify-center mx-auto mb-6">
                <MousePointer className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-bold mb-4">1. Elige tus Números</h3>
              <p className="text-gray-600">Selecciona tus números de la suerte de nuestra cuadrícula interactiva</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-brand-green rounded-full flex items-center justify-center mx-auto mb-6">
                <FaWhatsapp className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-bold mb-4">2. Confirma por WhatsApp</h3>
              <p className="text-gray-600">Recibirás un mensaje de confirmación con tus números seleccionados</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-brand-green rounded-full flex items-center justify-center mx-auto mb-6">
                <CreditCard className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-bold mb-4">3. Paga y Participa</h3>
              <p className="text-gray-600">Realiza tu pago y recibe tu boleto digital oficial</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="preguntas" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Preguntas Frecuentes</h2>
          
          <div className="max-w-3xl mx-auto space-y-6">
            {faqItems.map((item, index) => (
              <Card key={index} className="bg-white shadow-md">
                <CardContent className="p-0">
                  <Button
                    variant="ghost"
                    className="w-full text-left p-6 justify-between h-auto"
                    onClick={() => toggleFAQ(index)}
                  >
                    <span className="text-lg font-semibold">{item.question}</span>
                    <span className={`transform transition-transform ${expandedFAQ === index ? 'rotate-180' : ''}`}>
                      ▼
                    </span>
                  </Button>
                  {expandedFAQ === index && (
                    <div className="px-6 pb-6">
                      <p className="text-gray-600">{item.answer}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Contacto</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-brand-green text-white">
              <CardContent className="p-6">
                <FaWhatsapp className="text-3xl mb-4 mx-auto" />
                <h3 className="text-xl font-bold mb-2">WhatsApp</h3>
                <p>+52 662 123 4567</p>
              </CardContent>
            </Card>
            
            <Card className="bg-brand-green text-white">
              <CardContent className="p-6">
                <Phone className="text-3xl mb-4 mx-auto" />
                <h3 className="text-xl font-bold mb-2">Teléfono</h3>
                <p>662 123 4567</p>
              </CardContent>
            </Card>
            
            <Card className="bg-brand-green text-white">
              <CardContent className="p-6">
                <MapPin className="text-3xl mb-4 mx-auto" />
                <h3 className="text-xl font-bold mb-2">Ubicación</h3>
                <p>Hermosillo, Sonora</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Single Modal System - Only one modal active at a time */}
      {/* Sistema de modal único - solo un modal a la vez */}
      {activeModal === 'ticketGrid' && (
        <TicketGrid onClose={closeModal} onProceedToCheckout={handleProceedToCheckout} />
      )}

      {activeModal === 'luckyMachine' && (
        <LuckyMachine onClose={closeModal} onProceedToCheckout={handleProceedToCheckout} />
      )}

      {activeModal === 'verifier' && (
        <TicketVerifier onClose={closeModal} />
      )}

      {activeModal === 'demo' && (
        <TicketDemo onClose={closeModal} />
      )}

      {activeModal === 'checkout' && selectedNumbers.length > 0 && (
        <CheckoutForm
          selectedNumbers={selectedNumbers}
          onClose={closeModal}
          onComplete={handleCheckoutComplete}
        />
      )}

      {activeModal === 'digitalTicket' && ticketData && (
        <DigitalTicket ticketData={ticketData} onClose={closeModal} />
      )}
    </div>
  );
}
