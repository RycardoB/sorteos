import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  TicketIcon, 
  CheckCircle, 
  Clock, 
  DollarSign,
  Download,
  MessageCircle,
  Settings,
  Eye
} from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";
import AdminDashboard from "@/components/admin-dashboard";
import RaffleSettings from "@/components/raffle-settings";
import TicketDemo from "@/components/ticket-demo";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Ticket } from "@shared/schema";

export default function Admin() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [showTicketDemo, setShowTicketDemo] = useState(false);
  const { toast } = useToast();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
    refetchInterval: 5000,
  });

  const { data: tickets, isLoading: ticketsLoading } = useQuery<Ticket[]>({
    queryKey: ["/api/tickets"],
    refetchInterval: 10000,
  });

  const markAsPaidMutation = useMutation({
    mutationFn: async (ticketNumber: number) => {
      return apiRequest("PATCH", `/api/tickets/${ticketNumber}/paid`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Éxito",
        description: "Boleto marcado como pagado",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "No se pudo marcar el boleto como pagado",
        variant: "destructive",
      });
    },
  });

  const sendRemindersMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/admin/send-reminders");
    },
    onSuccess: () => {
      toast({
        title: "Recordatorios Enviados",
        description: "Se enviaron recordatorios a todos los boletos apartados",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudieron enviar los recordatorios",
        variant: "destructive",
      });
    },
  });

  const sendWhatsApp = (phone: string, ticketNumber: number) => {
    const message = `Hola, tienes el boleto #${ticketNumber.toString().padStart(4, '0')} apartado. Completa tu pago para asegurar tu participación en el sorteo.`;
    const whatsappUrl = `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const exportData = () => {
    if (!tickets) return;
    
    const csvContent = [
      ['Número', 'Cliente', 'Teléfono', 'Email', 'Estado_MX', 'Status', 'Fecha Reserva', 'Fecha Pago', 'Monto'].join(','),
      ...tickets.map(ticket => [
        ticket.number,
        ticket.customerName || '',
        ticket.customerPhone || '',
        ticket.customerEmail || '',
        ticket.customerState || '',
        ticket.status,
        ticket.reservedAt ? new Date(ticket.reservedAt).toLocaleDateString() : '',
        ticket.purchasedAt ? new Date(ticket.purchasedAt).toLocaleDateString() : '',
        ticket.totalAmount || 0
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `boletos_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sold':
        return <Badge className="bg-green-100 text-green-800">Pagado</Badge>;
      case 'reserved':
        return <Badge className="bg-yellow-100 text-yellow-800">Apartado</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Disponible</Badge>;
    }
  };

  const filteredTickets = tickets?.filter(ticket => 
    ticket.status !== 'available' && (
      ticket.number.toString().includes(searchTerm) ||
      ticket.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.customerPhone?.includes(searchTerm)
    )
  ) || [];

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-green mx-auto"></div>
          <p className="mt-4 text-gray-600">Cargando panel administrativo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-gray-800">Panel Administrativo</h1>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              onClick={() => setShowSettings(true)}
              className="bg-gray-600 hover:bg-gray-700 text-white"
            >
              <Settings className="w-4 h-4 mr-2" />
              Configurar Sorteo
            </Button>
            <Button
              onClick={() => setShowTicketDemo(true)}
              variant="outline"
              className="border-brand-green text-brand-green hover:bg-brand-green hover:text-white"
            >
              <Eye className="w-4 h-4 mr-2" />
              Ver Boleto
            </Button>
            <Button
              onClick={() => sendRemindersMutation.mutate()}
              disabled={sendRemindersMutation.isPending}
              className="bg-brand-green hover:bg-brand-green-dark text-white"
            >
              <FaWhatsapp className="w-4 h-4 mr-2" />
              {sendRemindersMutation.isPending ? "Enviando..." : "Enviar Recordatorios"}
            </Button>
            <Button
              onClick={exportData}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Boletos</p>
                  <p className="text-3xl font-bold text-gray-900">{stats?.total || 0}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <TicketIcon className="text-blue-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Vendidos</p>
                  <p className="text-3xl font-bold text-brand-green">{stats?.sold || 0}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="text-brand-green text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Apartados</p>
                  <p className="text-3xl font-bold text-yellow-600">{stats?.reserved || 0}</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Clock className="text-yellow-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Ingresos</p>
                  <p className="text-3xl font-bold text-brand-red">
                    ${stats?.revenue?.toLocaleString() || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="text-brand-red text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <AdminDashboard stats={stats} />
        
        {/* Ticket Management */}
        <Card className="mt-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Gestión de Boletos</CardTitle>
              <div className="flex items-center space-x-4">
                <Input
                  placeholder="Buscar por número, nombre o teléfono..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-80"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {ticketsLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-green mx-auto"></div>
                <p className="mt-4 text-gray-600">Cargando boletos...</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Boleto</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Teléfono</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Estado (MX)</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Monto</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTickets.map((ticket) => (
                      <TableRow key={ticket.id}>
                        <TableCell className="font-medium">
                          #{ticket.number.toString().padStart(4, '0')}
                        </TableCell>
                        <TableCell>{ticket.customerName || '-'}</TableCell>
                        <TableCell>{ticket.customerPhone || '-'}</TableCell>
                        <TableCell>{ticket.customerEmail || '-'}</TableCell>
                        <TableCell>{ticket.customerState || '-'}</TableCell>
                        <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                        <TableCell>
                          {ticket.reservedAt ? new Date(ticket.reservedAt).toLocaleDateString() : '-'}
                        </TableCell>
                        <TableCell>
                          {ticket.totalAmount ? `$${ticket.totalAmount.toLocaleString()}` : '-'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {ticket.status === 'reserved' && (
                              <Button
                                size="sm"
                                onClick={() => markAsPaidMutation.mutate(ticket.number)}
                                disabled={markAsPaidMutation.isPending}
                                className="bg-brand-green hover:bg-brand-green-dark text-white"
                              >
                                Marcar Pagado
                              </Button>
                            )}
                            {ticket.customerPhone && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => sendWhatsApp(ticket.customerPhone!, ticket.number)}
                              >
                                <MessageCircle className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                {filteredTickets.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No se encontraron boletos que coincidan con la búsqueda
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Settings Modal */}
      {showSettings && (
        <RaffleSettings onClose={() => setShowSettings(false)} />
      )}

      {showTicketDemo && (
        <TicketDemo onClose={() => setShowTicketDemo(false)} />
      )}
    </div>
  );
}
