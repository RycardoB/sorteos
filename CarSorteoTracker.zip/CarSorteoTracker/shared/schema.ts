import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  number: integer("number").notNull().unique(),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  customerEmail: text("customer_email"),
  customerState: text("customer_state"),
  status: text("status").notNull().default("available"), // available, reserved, sold
  reservedAt: timestamp("reserved_at"),
  purchasedAt: timestamp("purchased_at"),
  totalAmount: integer("total_amount"),
});

export const raffles = pgTable("raffles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  vehicleModel: text("vehicle_model").notNull(),
  vehicleYear: integer("vehicle_year").notNull(),
  vehicleImage: text("vehicle_image"),
  ticketPrice: integer("ticket_price").notNull(),
  totalTickets: integer("total_tickets").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  reservedAt: true,
  purchasedAt: true,
});

export const insertRaffleSchema = createInsertSchema(raffles).omit({
  id: true,
});

export const updateTicketSchema = createInsertSchema(tickets).partial().omit({
  id: true,
  number: true,
});

export type Ticket = typeof tickets.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type UpdateTicket = z.infer<typeof updateTicketSchema>;
export type Raffle = typeof raffles.$inferSelect;
export type InsertRaffle = z.infer<typeof insertRaffleSchema>;
